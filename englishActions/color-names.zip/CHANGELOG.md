## 1.0.0 (2015-12-26)

- Changed: Flipped references from name to hex
- Updated: Description and documentation

## 1.0.0 (2015-12-17)

- Added: Initial version
