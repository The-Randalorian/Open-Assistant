# Color Names

The largest list of color names referenceable by hex.

## Usage

```js
require('color-names')['#d2f6de']; // Blue Romance
```
